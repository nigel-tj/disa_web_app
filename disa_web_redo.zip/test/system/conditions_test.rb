require "application_system_test_case"

class ConditionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit conditions_url
  #
  #   assert_selector "h1", text: "Condition"
  # end
end
